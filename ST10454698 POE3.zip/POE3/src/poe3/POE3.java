/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe3;

/**
 *
 * @author ST10454698
 
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class POE3 {
    public static final List<Task> tasks = new ArrayList<>();
    public static boolean isLoggedIn = false;

    public static final String[] firstNames = new String[100];
    public static final String[] lastNames = new String[100]; 
    public static final String[] usernames = new String[100];
    public static final String[] passwords = new String[100];
   
    public static int userCount = 0;

    // Define constants for menu options
    public static final String OPTION_ADD_TASKS = "1";
    public static final String OPTION_SHOW_REPORT = "2";
    public static final String OPTION_SEARCH_TASK_BY_NAME = "3";
    public static final String OPTION_SEARCH_TASKS_BY_DEVELOPER = "4";
    public static final String OPTION_DELETE_TASK_BY_NAME = "5";
    public static final String OPTION_DISPLAY_TASKS_WITH_STATUS_DONE = "6";
    public static final String OPTION_DISPLAY_LONGEST_DURATION_TASK = "7";
    public static final String OPTION_QUIT = "8";

    public static void main(String[] args) {
        while (true) {
            String choice = JOptionPane.showInputDialog(null,
                    "Welcome to EasyKanBan.\n1. Quit\n2. Register\n3. Login\nEnter your choice:");
            switch (choice) {
                case "1" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye. Be back soon!");
                    System.exit(0);
                }
                case "2" -> register();
                case "3" -> {
                    isLoggedIn = login();
                    if (isLoggedIn) {
                        showMenu();
                    } else {
                        JOptionPane.showMessageDialog(null, "Login failed");
                    }
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }

    public static void register() {
        String firstName = JOptionPane.showInputDialog(null, "Please enter your first name:");
        String lastName = JOptionPane.showInputDialog(null, "Please enter your last name:"); 
        String username = JOptionPane.showInputDialog(null, "Please enter a username:");
        String password = JOptionPane.showInputDialog(null, "Please enter a password:");

        if (username != null && password != null && firstName != null && lastName != null &&
                username.contains("_") && username.length() <= 5) {
            firstNames[userCount] = firstName;
            lastNames[userCount] = lastName; 
            usernames[userCount] = username;
            passwords[userCount] = password;
            userCount++;
            JOptionPane.showMessageDialog(null, "Registration successful! You can now login.");
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
        }
    }

    public static boolean login() {
        String username = JOptionPane.showInputDialog(null, "Enter your username:");
        String password = JOptionPane.showInputDialog(null, "Enter your password:");

        for (int i = 0; i < userCount; i++) {
            if (username.equals(usernames[i]) && password.equals(passwords[i])) {
                JOptionPane.showMessageDialog(null, "Login successful! Welcome, " + firstNames[i] + " " + lastNames[i] + ". It's great to see you again!");
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
        return false;
    }

    public static void showMenu() {
        while (isLoggedIn) {
            String option = JOptionPane.showInputDialog(null,
                    "Select an option:\n1. Add tasks\n2. Show report\n3. Search task by name\n4. Search tasks by developer\n5. Delete task by name\n6. Display tasks with status 'done'\n7. Display task with the longest duration\n8. Quit",
                    "EasyKanban", JOptionPane.PLAIN_MESSAGE);

            switch (option) {
                case OPTION_ADD_TASKS:
                    addTasks();
                    break;
                case OPTION_SHOW_REPORT:
                    displayAllTasks();
                    break;
                case OPTION_SEARCH_TASK_BY_NAME:
                    searchTaskByName();
                    break;
                case OPTION_SEARCH_TASKS_BY_DEVELOPER:
                    searchTasksByDeveloper();
                    break;
                case OPTION_DELETE_TASK_BY_NAME:
                    deleteTaskByName();
                    break;
                case OPTION_DISPLAY_TASKS_WITH_STATUS_DONE:
                    displayTasksWithStatus("done");
                    break;
                case OPTION_DISPLAY_LONGEST_DURATION_TASK:
                    displayLongestDurationTask();
                    break;
                case OPTION_QUIT:
                    JOptionPane.showMessageDialog(null, "Goodbye. Be back soon!");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option");
                    break;
            }
        }
    }

    public static void addTasks() {
        try {
            int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks to add"));

            for (int i = 0; i < numTasks; i++) {
                String taskName = JOptionPane.showInputDialog("Please enter task name");
                String taskDescription;
                do {
                    taskDescription = JOptionPane.showInputDialog("Please enter task description (max 50 characters)");
                } while (taskDescription == null || taskDescription.length() > 50);

                String developerDetails = JOptionPane.showInputDialog("Please enter developer details");
                int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Please enter task duration in hours"));
                String taskID = Task.createTaskID(taskName, developerDetails, i);

                String[] statusOptions = {"To Do", "Done", "Doing"};
                String taskStatus = (String) JOptionPane.showInputDialog(null, 
                        "Select task status:", 
                        "Task Status", 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        statusOptions, 
                        statusOptions[0]);

                Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskID, taskStatus);
                tasks.add(task);

                JOptionPane.showMessageDialog(null, task.printTaskDetails());
            }

            int totalHours = Task.returnTotalHours(tasks);
            JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
        }
    }

    //Code Attribute #A
    public static void displayAllTasks() {
        StringBuilder report = new StringBuilder("Task Report:\n");
        for (Task task : tasks) {
            report.append(task).append("\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    public static void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter task name to search:");
        for (Task task : tasks) {
            if (task.taskName.equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + task.taskName + ", Developer: " + task.developerDetails + ", Status: " + task.taskStatus);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    public static void searchTasksByDeveloper() {
        String developer = JOptionPane.showInputDialog("Enter developer name to search tasks:");
        StringBuilder result = new StringBuilder("Tasks assigned to " + developer + ":\n");
        for (Task task : tasks) {
            if (task.developerDetails.equalsIgnoreCase(developer)) {
                result.append("Task Name: ").append(task.taskName).append(", Status: ").append(task.taskStatus).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter task name to delete:");
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).taskName.equalsIgnoreCase(taskName)) {
                tasks.remove(i);
                JOptionPane.showMessageDialog(null, "Task deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    public static void displayTasksWithStatus(String status) {
        StringBuilder result = new StringBuilder("Tasks with status '" + status + "':\n");
        for (Task task : tasks) {
            if (task.taskStatus.equalsIgnoreCase(status)) {
                result.append("Developer: ").append(task.developerDetails).append(", Task Name: ").append(task.taskName).append(", Duration: ").append(task.taskDuration).append(" hours\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void displayLongestDurationTask() {
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks available.");
            return;
        }

        Task longestTask = tasks.get(0);
        for (Task task : tasks) {
            if (task.taskDuration > longestTask.taskDuration) {
                longestTask = task;
            }
        }
        JOptionPane.showMessageDialog(null, "Developer: " + longestTask.developerDetails + ", Duration: " + longestTask.taskDuration + " hours");
    }
}

class Task {
    public String taskName;
    public String taskDescription;
    public String developerDetails;
    public int taskDuration;
    public String taskID;
    public String taskStatus;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskID, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = taskID;
        this.taskStatus = taskStatus;
    }

    public static String createTaskID(String taskName, String developerDetails, int taskIndex) {
        return taskName.substring(0, 2).toUpperCase() + developerDetails.substring(0, 2).toUpperCase() + taskIndex;
    }

    public String printTaskDetails() {
        return "Task ID: " + taskID + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nDeveloper Details: " + developerDetails + "\nTask Duration: " + taskDuration + " hours\nTask Status: " + taskStatus;
    }

    public static int returnTotalHours(List<Task> tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.taskDuration;
        }
        return totalHours;
    } //Code Attribute #B

    @Override
    public String toString() {
        return "Task ID: " + taskID + ", Task Name: " + taskName + ", Task Description: " + taskDescription + ", Developer Details: " + developerDetails + ", Task Duration: " + taskDuration + " hours, Task Status: " + taskStatus;
    }
}


// Code Attribute #A
// Display all tasks
//This method was taken from MKyong.com
//https://mkyong.com/swing/java-swing-how-to-make-a-simple-dialog/
//Author is Marilana

//Code Attribute #B
//Display all tasks
//This method was taken from Stack Overflow
//https://stackoverflow.com/questions/72808087/c-sharp-async-tasks-assign-a-int-to-every-task-based-on-its-order
//Author not found

