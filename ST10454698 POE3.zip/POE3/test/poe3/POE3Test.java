/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poe3;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class POE3Test {
    
    public POE3Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class POE3.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        POE3.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of register method, of class POE3.
     */
    @Test
    public void testRegister() {
        System.out.println("register");
        POE3.register();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class POE3.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        boolean expResult = false;
        boolean result = POE3.login();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showMenu method, of class POE3.
     */
    @Test
    public void testShowMenu() {
        System.out.println("showMenu");
        POE3.showMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTasks method, of class POE3.
     */
    @Test
    public void testAddTasks() {
        System.out.println("addTasks");
        POE3.addTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayAllTasks method, of class POE3.
     */
    @Test
    public void testDisplayAllTasks() {
        System.out.println("displayAllTasks");
        POE3.displayAllTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTaskByName method, of class POE3.
     */
    @Test
    public void testSearchTaskByName() {
        System.out.println("searchTaskByName");
        POE3.searchTaskByName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTasksByDeveloper method, of class POE3.
     */
    @Test
    public void testSearchTasksByDeveloper() {
        System.out.println("searchTasksByDeveloper");
        POE3.searchTasksByDeveloper();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTaskByName method, of class POE3.
     */
    @Test
    public void testDeleteTaskByName() {
        System.out.println("deleteTaskByName");
        POE3.deleteTaskByName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayTasksWithStatus method, of class POE3.
     */
    @Test
    public void testDisplayTasksWithStatus() {
        System.out.println("displayTasksWithStatus");
        String status = "";
        POE3.displayTasksWithStatus(status);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongestDurationTask method, of class POE3.
     */
    @Test
    public void testDisplayLongestDurationTask() {
        System.out.println("displayLongestDurationTask");
        POE3.displayLongestDurationTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
